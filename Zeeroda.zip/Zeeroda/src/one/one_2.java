package one;

public class one_2 {

}
